﻿using System;
using System.Data;
using MailBee;
using MailBee.AddressCheck;
using MailBee.SmtpMail;
using MailBee.DnsMX;
using MailBee.Mime;
using MailBee.EwsMail;
using MailBee.Pop3Mail;
using MailBee.ImapMail;
using MailBee.Security;
using MailBee.AntiSpam;
using MailBee.Outlook;
using MailBee.Pdf;
using System.IO;


class Program
{
    // This enum defines the status of an e-mail address in our data table.
    enum AddressStatus
    {
        Good = 0,
        ProbablyGreylisted = 1,
        ProbablyBad = 2,
        Bad = 3
    }

    const string EmailColumn = "email";
    const string StatusColumn = "status";
    // In real apps, you'll get this data table from your database.
    // In the sample, we build it directly in the code.
    private static DataTable GetDataTable()
    {

        DataTable workTable = new DataTable();
        workTable.Columns.Add(EmailColumn, typeof(string));
        workTable.Columns.Add(StatusColumn, typeof(AddressStatus));

        // Populate the data table with several addresses (some are surely wrong)
        // and initially mark them Good. We believe they are good until proven otherwise.

        
        string path = @"C:\access\Email_Verification\Input\input.csv";
      

        StreamReader file = new StreamReader(path);
        string[] emails = new string[1000];
        for (int x=0;x<emails.Length;x++)
            {
            emails[x] = file.ReadLine();
            }

        file.Close();


        foreach (string email in emails)
            {
                DataRow row = workTable.NewRow();
                row[EmailColumn] = email;
                row[StatusColumn] = AddressStatus.Good;
                workTable.Rows.Add(row);
            }
     


        return workTable;

        
    }

    // This method executes when the e-mail address is about to be checked.
    private static void valid_Verifying(object sender, VerifyingEventArgs e)
    {
        // In this sample, we won't check addresses which have already proven to be bad.
        // You can use the same idea to skip any other addresses you wish, such as
        // to implement black-listing or white-listing.
        if ((AddressStatus)e.Row[StatusColumn] == AddressStatus.Bad)
        {
            e.VerifyIt = false;
        }
    }

    // This method executes after the e-mail address was checked.
    private static void valid_Verified(object sender, VerifiedEventArgs e)
    {
        // Nothing new in this part.
        Console.WriteLine("*** Verified ***");
        Console.WriteLine("Email: " + e.Email);
        Console.WriteLine("Result: " + e.Result.ToString());
        if (e.Reason != null)
        {
            Console.WriteLine("Reason: " + e.Reason.Message);
        }

        // Interesting part starts here.
        AddressStatus previousStatus = (AddressStatus)e.Row[StatusColumn];
        AddressStatus newStatus = previousStatus;

        switch (e.Result)
        {
            case AddressValidationLevel.OK:
                // If the address was Good, it stays Good. If it was Probably"Something",
                // it has now cleared our suspicions, congrats!
                if (previousStatus != AddressStatus.Good)
                {
                    newStatus = AddressStatus.Good;
                }
                break;
            case AddressValidationLevel.RegexCheck:
                // If the address failed regex check, it just had bad syntax.
                // Does not make sense to give it a second chance.
                newStatus = AddressStatus.Bad;
                break;
            case AddressValidationLevel.DnsQuery:
                if (previousStatus == AddressStatus.Good ||
                    previousStatus == AddressStatus.ProbablyGreylisted)
                {
                    // Give the address which was good before, a second chance. We also do this for
                    // "probably greylisted" addresses because from DNS MX point of view they are good
                    // (valid MX host, running SMTP service) and DNS error is something new for them,
                    // so there is a chance it's a temporary issue.
                    newStatus = AddressStatus.ProbablyBad;
                }
                else
                {
                    // The address had already been given second chance before and thus had ProbablyBad status.
                    // Execute it. No mercy this time. But in real apps you better take this decision on at least
                    // 3rd failed attempt, and at least 3 days should pass since the first attempt. Give
                    // the e-mail service of the recipient some time to fix the issues they may be experiencing,
                    // or the mailbox was just full and the user had no time to get some free space there.
                    newStatus = AddressStatus.Bad;
                }
                break;
            case AddressValidationLevel.SmtpConnection:
                // In this sample, we take the same decisions in SmtpConnection case like we do for DnsQuery.
                // This is because the reasons are pretty similar in most cases. The domain could go down due
                // to the name server issue, the same can happen with a SMTP MX e-mail server. This differs
                // from the situation when the SMTP MX server does respond but says "No" (see below).
                if (previousStatus == AddressStatus.Good ||
                    previousStatus == AddressStatus.ProbablyGreylisted)
                {
                    newStatus = AddressStatus.ProbablyBad;
                }
                else
                {
                    newStatus = AddressStatus.Bad;
                }
                break;
            case AddressValidationLevel.SendAttempt:
                // Did the connection simply break or did the server actually say "No"?
                // Connection break may indicate a temporary issue with the SMTP MX server.
                IMailBeeNegativeSmtpResponseException negativeResponseEx;
                negativeResponseEx = e.Reason as IMailBeeNegativeSmtpResponseException;
                bool isNegativeReply = (negativeResponseEx != null);

                // For No errors, we need to make sure this is the final verdict of the SMTP MX server.
                // If the error is transient rather than the final verdict, it leaves us a second chance to try.
                if (isNegativeReply && !negativeResponseEx.IsTransientError)
                {
                    // The SMTP MX server which is charge for the given e-mail address said us strict "No".
                    // We don't know the exact reason (maybe, your IP address is blacklisted by some RBLs),
                    // but under the current circumstances the given e-mail address cannot receive e-mail from us.
                    newStatus = AddressStatus.Bad;
                    break;
                }

                // At this point, we have only temporary SMTP MX errors left, such as broken connections or
                // greylisting ("Try again later" responses). For such errors, giving second chances does make sense.

                if (previousStatus == AddressStatus.Good)
                {
                    if (isNegativeReply)
                    {
                        // The server replied "No, but try again later". It's legit thing, so there is a good
                        // chance there IS a real e-mail account under the given name there.
                        newStatus = AddressStatus.ProbablyGreylisted;
                    }
                    else
                    {
                        // The server suddenly broke the connection. Give it one second chance, but no more.
                        newStatus = AddressStatus.ProbablyBad;
                    }
                }
                else if (previousStatus == AddressStatus.ProbablyGreylisted)
                {
                    // The server said "Try again later" or broke the connection?
                    if (isNegativeReply)
                    {
                        // Greylisting returned the same result second time in a row. Maybe, it wasn't greylisting
                        // at all? Give this e-mail address one more chance, but our patience is nearly over.
                        newStatus = AddressStatus.ProbablyBad;
                    }
                    else
                    {
                        // Well, "If isNegativeReply" is actually redundant here. If the server broke the connection
                        // instead of saying "Better luck next time", our assumption remains the same. There is
                        // still a small chance that the server will accept the given address next time, so give it
                        // one more shot to try. In your apps, however, you may consider different logic here.
                        newStatus = AddressStatus.ProbablyBad;
                    }
                }
                else
                {
                    // We're tired of all that "Try again later" occurring 3 times in a row and repetitive
                    // disconnects during send attempts. Consider the e-mail address dead.
                    newStatus = AddressStatus.Bad;
                }
                break;
        }

        if (previousStatus != newStatus)
        {
            // Update the status in the data table. You may also need to do Commit, Update
            // or whatever is required to apply the changes to your database.
            e.Row[StatusColumn] = newStatus;
        }

        Console.WriteLine();
    }

    // Dumps the contents of the data table to console. We use it how the statuses change
    // over the time with making new attempts to verify the corresponding e-mails addresses.
    private static void DisplayDataTable(DataTable data)
    {
       
        TextWriter txt = new StreamWriter(@"C:\access\Email_Verification\Output\verification_result.csv");

        foreach (DataRow row in data.Rows)
        {
           
            txt.WriteLine(string.Format("{0},{1}",
                row[EmailColumn].ToString(), ((AddressStatus)row[StatusColumn]).ToString()));
            Console.WriteLine(string.Format("{0},{1}",
                row[EmailColumn].ToString(), ((AddressStatus)row[StatusColumn]).ToString()));
        }
        Console.WriteLine();
        txt.Close();
    
    }

    static void Main(string[] args)
    {
        // Common initialization, like in previous samples.
        EmailAddressValidator valid = new EmailAddressValidator("MN120-2EE6E6C8E63DE60BE6F1619BC480-92BD");
        valid.DnsServers.Autodetect();
        valid.Log.Enabled = true;
        valid.Log.Format = LogFormatOptions.AddContextInfo;
        valid.Log.Filename = @"C:\vinoth\log\log.txt";
        valid.Log.Clear();
        valid.Verifying += new VerifyingEventHandler(valid_Verifying);
        valid.Verified += new VerifiedEventHandler(valid_Verified);
        valid.MaxThreadCount = -1;

        DataTable data = GetDataTable();

        valid.Verify(data, EmailColumn);
        DisplayDataTable(data);

        Console.WriteLine("Press any key to exit");
        Console.ReadKey(true);
    }
}